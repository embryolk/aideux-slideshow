var Slideshow = function(images, container){
	this.container = container;
	this.container.css("width", (images.length * 100) + "%");
	
	this.images = [];
	for( var i in images ){
		var div = $("<div/>",{
			class: 'slide',
			style: 'background-image: url('+images[i]+');'
		}).appendTo(container);
		this.images.push({
			src: images[i],
			div: div
		});
	}
	
	this.currentLocation = 0;
	
	var self = this;
	$(document).keydown(function(ev){
		var move = false;
		if( ev.which === 37 ) { // left
			if( self.currentLocation > 0 ){
				self.currentLocation--;
				move = true;
			}
		} else if (ev.which === 39) { // right
			if( self.currentLocation < self.images.length-1 ){
				self.currentLocation++;
				move = true;
			}
		}
		if( move ){
			self.container.animate({
				"left": -(self.currentLocation*100)+"vw"
			}, 300);
		}
	});
	
};

